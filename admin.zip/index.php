<?php

header("Location: dashboard");